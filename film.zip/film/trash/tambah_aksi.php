<?php 
// koneksi database
include 'koneksi.php';
 
// menangkap data yang di kirim dari form
$id_artikel_film = $_POST['id_artikel_film'];
$judul = $_POST['judul'];
$deskripsi = $_POST['deskripsi'];
 
// menginput data ke database
mysqli_query($koneksi,"insert into film values('$kategori','$artikel_film')");
 
// mengalihkan halaman kembali ke index.php
header("location:index.php");
 
?>