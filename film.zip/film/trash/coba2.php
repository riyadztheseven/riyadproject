<title>Teks di Pinggir Gambar</title>
    <style>
        .image-container {
            position: relative;
            width: 300px; /* Sesuaikan lebar gambar sesuai kebutuhan Anda */
        }

        .image {
            max-width: 100%;
            height: auto;
        }

        .text-overlay {
            position: absolute;
            top: 0;
            left: 0;
            background-color: rgba(0, 0, 0, 0.5); /* Latar belakang teks dengan transparansi */
            color: white; /* Warna teks */
            padding: 10px; /* Jarak dari tepi gambar */
        }
    </style>
</head>
<body>
    <div class="image-container">
        <img class="image" src="gambar-anda.jpg" alt="Gambar Anda">
        <div class="text-overlay">
            Teks di Pinggir Gambar
        </div>
    </div>
</body>
</html>
Dalam contoh di atas, kami memiliki elemen .image-container yang berisi gambar dan elemen .text-overlay. Elemen .text-overlay diatur sebagai elemen anak dari .image-container, dan dengan pengaturan CSS, elemen ini ditempatkan di atas gambar dengan position: absolute;. Anda dapat menyesuaikan lebar gambar, warna latar belakang, dan teks sesuai kebutuhan Anda.

Pastikan untuk mengganti "gambar-anda.jpg" dengan URL atau path gambar yang ingin Anda tampilkan.





