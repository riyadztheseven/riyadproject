<?php
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $publish = $_POST['publish'];
    $judul = $_POST['judul'];
    $gambar = $_POST['gambar'];
    $deskripsi = $_POST['deskripsi'];
    $jumlah_episode = $_POST['jumlah_episode'];
    $tanggal_rilis = $_POST['tanggal_rilis'];
    $studio_produksi = $_POST['studio_produksi'];
    $durasi_film = $_POST['durasi_film'];
    $genre = $_POST['genre'];


    $sql = "INSERT INTO hollywood (publish, judul, gambar, deskripsi, jumlah_episode, tanggal_rilis, studio_produksi, durasi_film, genre)
             VALUES ('$publish', '$judul', '$gambar', '$deskripsi', '$jumlah_episode', '$tanggal_rilis', '$studio_produksi', '$durasi_film', '$genre')";
}

if ($koneksi->query($sql) === TRUE) {
    header("Location: hollywood-admin.php");
} else {
    echo "Error : Pesan tidak terkirim";
}
?>