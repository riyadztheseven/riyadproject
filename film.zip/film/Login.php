<?php
        session_start();
        require_once "koneksi.php";

        if (isset($_POST["login"])) {
            $username = $_POST["username"];
            $password = $_POST["password"];

            $query = "SELECT * FROM login WHERE username = '$username' AND password = '$password'";
            $result = $koneksi->query($query);
            $query2 = "SELECT * FROM login WHERE username = '$username' AND password = '$password'";
            $result2 = $koneksi->query($query2);

if ($result->num_rows > 0) {
        $_SESSION["username"] = $username;
        header("Location: panitia.php");
} else {
    if ($result2->num_rows > 0) {
        $_SESSION["username"] = $username;
        header("Location: panitia.php");
        
        }
      
        echo "<script>alert('Username atau password anda salah. silahkan coba lagi bray!!!')</script>";

      }
    }
  ?>
<!DOCTYPE html>
<!DOCTYPE html>
<html>

<head>
  <title>Login Admin</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-image: url('image/bg-login.png');
      background-size: cover;
      background-repeat: no-repeat;
      background-attachment: fixed;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }

    .login-container {
      width: 400px;
      padding: 20px;
      background-color: rgba(255, 255, 255, 0.9);
      border-radius: 10px;
      box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
      text-align: center;
      transform: translateZ(0);
      transition: transform 0.3s ease-in-out;
    }
    

    .login-container:hover {
      transform: scale(1.02);
    }

    h2 {
      color: #333;
    }

    label {
      display: block;
      margin-top: 10px;
      margin-bottom: 10px;
    }

    input[type="password"] {
      width: 80%;
      padding: 10px;
      margin-top: 5px;
      border: 1px solid #ccc;
      border-radius: 0px;
    }

    button {
      background-color: #dc0000bd;
      color: #fff;
      border: none;
      padding: 10px 40px;
      margin-top: 15px;
      border-radius: 0px;
      cursor: pointer;
      transition: background-color 0.3s ease-in-out;
    }

    button:hover {
      background-color: #dc0000;
    }

    p#error-message {
      color: red;
      font-size: 14px;
    }
  </style>
</head>

<body>
  <div class="login-container">
    <h2>LOGIN ADMIN</h2>
    <label for="password">Masukan Password Untuk Login</label>
    <input type="password" id="password" placeholder="password">
    <button onclick="login()">Login</button>
    <p id="error-message"></p>
  </div>

  <script>
    function login() {
      var password = document.getElementById("password").value;
      var errorMessage = document.getElementById("error-message");

      if (password === "") {
        errorMessage.textContent = "Masukan Password nya Dulu Yaa!.";
        return; // Tidak melanjutkan proses login
      }

      // Ganti "yourAdminPassword" dengan kata sandi admin yang Anda inginkan
      if (password === "riyad") {
        errorMessage.textContent = ""; // Menghapus pesan kesalahan jika ada
        alert("Login successful. Welcome Admin Ryadzz The Creator!");
        window.location.href = "index-admin.php";
        // Redirect ke halaman admin atau tampilan lain yang sesuai
      } else {
        errorMessage.textContent = "Waduh, Password nya Ada Yang Salah, Cek Kembali !";
      }
    }
  </script>
</body>

</html>