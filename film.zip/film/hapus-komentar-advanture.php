<?php
include 'koneksi.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Hapus data berdasarkan ID
    $sql_delete = "DELETE FROM komentar_advanture WHERE id = $id";
    if ($koneksi->query($sql_delete) === TRUE) {
        header("Location: komentar-admin.php");
    } else {
        echo "Error: Data gagal dihapus";
    }
} else {
    echo "ID tidak diberikan.";
}
?>