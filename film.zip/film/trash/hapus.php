<?php
include 'koneksi.php';

// Pastikan $id adalah integer yang valid
$id = (isset($_GET['id'])) ? intval($_GET['id']) : 0;

if ($id > 0) {
    // Lakukan penghapusan setelah melakukan validasi
    $result = mysqli_query($koneksi, "SELECT nama FROM komentar WHERE id='$id'");
    
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $namakomentar = $row['nama'];

        $delete_query = "DELETE FROM komentar WHERE id='$id'";
        if (mysqli_query($koneksi, $delete_query)) {
            echo "<script>alert('Data $namakomentar berhasil dihapus.'); window.location.href = 'tampil.php';</script>";
        } else {
            echo "<script>alert('Error: " . mysqli_error($koneksi) . "'); window.location.href = 'tampil.php';</script>";
        }
    } else {
        echo "<script>alert('Data dengan ID $id tidak ditemukan.'); window.location.href = 'tampil.php';</script>";
    }
} else {
    // Tindakan jika $id tidak valid
    echo "<script>alert('ID tidak valid.'); window.location.href = 'tampil.php';</script>";
}

mysqli_close($koneksi);
?>
