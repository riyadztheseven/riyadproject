<?php
include 'koneksi.php';

if (isset($_POST['ubah_id'])) {
    $id = $_POST['ubah_id'];
    $Querynama = mysqli_real_escape_string($koneksi, $_POST['ubah_nama']);
    $QueryKomentar = mysqli_real_escape_string($koneksi, $_POST['ubah_Komentar']);

    $query = "UPDATE komentar SET nama='$Querynama', Komentar='$QueryKomentar' WHERE id = '$id'";
    $result = mysqli_query($koneksi, $query);

    if (!$result) {
        die("Gagal Di Ubah " . mysqli_errno($koneksi) . " - " . mysqli_error($koneksi));
    } else {
        header('Location: tampil.php');
        exit();
    }
}

$id = $_GET['id'];
$data = mysqli_query($koneksi, "SELECT * FROM komentar WHERE id='$id'");
while ($tampil = mysqli_fetch_array($data)) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Komentar</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style3.css">
</head>
<body>
<div class="page-content p-5" id="content">
    <button id="sidebarCollapse" type="button" class="btn btn-light bg-white rounded-pill shadow-sm px-4 mb-4"><i class="fa fa-bars mr-2"></i><small class="text-uppercase font-weight-bold">Menu</small></button>
    <div class="container-fluid">
        <form method="post" action="">
            <div class="mb-3">
                <label class="form-label">Id</label>
                <input name="ubah_id" type="number" class="form-control" value="<?php echo $tampil["id"]; ?>" readonly>
            </div>
            <div class="mb-3">
                <label class="form-label">Nama</label>
                <input name="ubah_nama" type="text" class="form-control" value="<?php echo $tampil["nama"]; ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Komentar</label>
                <input name="ubah_Komentar" type="text" class="form-control" value="<?php echo $tampil["Komentar"]; ?>">
            </div>
            <button type="submit" class="btn btn-sm btn-primary">Simpan</button>
        </form>
    </div>
</div>

<script src="js/js.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php } ?>
