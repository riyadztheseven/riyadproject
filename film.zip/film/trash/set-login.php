<?php
require_once "koneksi.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $LoginUsername = $_POST["un"];
    $LoginPassword = $_POST["pw"];

    $query = "SELECT * FROM akun WHERE username = '$LoginUsername' AND password = '$LoginPassword'";
    $action = $koneksi->query($query);

    if ($result->num_rows > 0) {
        header("Location: index-admin.php");
    } else {
        header("Location: admin-login.php");
    }
}
?>