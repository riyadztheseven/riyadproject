<?php
include 'koneksi.php';

$komentar = $_POST['komentar'];

$sql = "INSERT INTO komentar_anime ( komentar ) VALUES ('$komentar')";
$result = mysqli_query($koneksi, $sql);

if (!$result) {
	die("Query gagal dijalankan: " . mysqli_errno($koneksi) . " - " . mysqli_error($koneksi));
} else {
	header("Location: anime.php");
	exit();
}
?>