<?php
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $publish = $_POST['publish'];
    $judul = $_POST['judul'];
    $gambar = $_POST['gambar'];
    $deskripsi = $_POST['deskripsi'];
    $jumlah_episode = $_POST['jumlah_episode'];
    $musim_rilis = $_POST['musim_rilis'];
    $studio_produksi = $_POST['studio_produksi'];
    $durasi_episode = $_POST['durasi_episode'];
    $genre = $_POST['genre'];


    $sql = "INSERT INTO drakor (genre, publish, judul, gambar, deskripsi, jumlah_episode, musim_rilis, studio_produksi, durasi_episode)
             VALUES ('$genre', '$publish', '$judul', '$gambar', '$deskripsi', '$jumlah_episode', '$musim_rilis', '$studio_produksi', '$durasi_episode')";
}

if ($koneksi->query($sql) === TRUE) {
    header("Location: drakor-admin.php");
} else {
    echo "Error : Pesan tidak terkirim";
}
?>