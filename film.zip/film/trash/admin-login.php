<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RFP - Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body style="background-image: url('image/bg3.jpg');">

    <div class="my-form">
        <form class="form-area" method="post">
            <div class="form-title text-center">
                <h5 class="mt-0 mb-0">ISI FORM UNTUK <span style="color: red;">LOGIN</span></h5>
                <p id="errorMessage"></p>
                <hr class="mt-4 mb-4">
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password :</label>
                <input type="password" class="form-control" id="password" required>
            </div>
            <div class="mt-4 text-center">
                <button class="btn btn-danger" style="border-radius: 0px; padding: 4px 50px 4px 50px;"
                    onclick="login()">Login</button>
            </div>
        </form>
    </div>

    <script>
        function login() {
            var password = document.getElementById("password").value;
            var errorMessage = document.getElementById("error-message");

            if (password === "") {
                errorMessage.textContent = "Please enter a password.";
                return; // Tidak melanjutkan proses login
            }

            // Ganti "yourAdminPassword" dengan kata sandi admin yang Anda inginkan
            if (password === "riyad") {
                errorMessage.textContent = ""; // Menghapus pesan kesalahan jika ada
                alert("Login successful. Welcome Admin!");
                window.location.href = "index-admin.php";
                // Redirect ke halaman admin atau tampilan lain yang sesuai
            } else {
                errorMessage.textContent = "Incorrect password. Please try again.";
            }
        }
    </script>

    <style>
        .my-form {
            margin-top: 165px;
            padding: 0px 465px;

            .form-area {
                padding: 30px;
                box-shadow: 0px 0px 5px 1px #0000003f;
                background-color: #fff;
            }

            .form-control {
                border-radius: 0px;
                border-color: #0000003f;
            }
        }
    </style>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
        crossorigin="anonymous"></script>
</body>

</html>