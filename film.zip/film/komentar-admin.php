<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">

<head>
    <style>
        body {
            background-color: lightblue;
            background-image: url('image/bg3.jpg');
        }
    </style>
    <title>Kotak Pencarian</title>
    <style>
        .search-container {
            text-align: center;
            margin-top: 50px;
        }

        .search-box {
            padding: 10px;
            width: 300px;
            border: 1px solid #ccc;
            border-radius: 0px;
            font-size: 16px;
        }

        .search-button {
            padding: 10px 20px;
            background-color: #007BFF;
            color: #fff;
            border: none;
            border-radius: 0px;
            cursor: pointer;
        }
    </style>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>



</div>
</nav>
<title>Canuckington Post</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" charset="utf-8" />
</head>

<!-- BEGIN TOP -->
<div id="top">
    

</div>
<!-- END TOP -->
<!-- BEGIN HEADER -->
<div id="header">
    <div class="brand">
        <p class="fw-bold fs-1 mt-3 mb-0">ADM<span style="color: #dc0000;">I</span>N P<span style="color: #dc0000;">A</span>GE</p>
        <p class="mb-0">Dalam kategori Horror, Anime, Hollywood, Drakor, Romance, Superhero, dan Adventure</p>
    </div>
</div>

<!-- END HEADER -->
<!-- BEGIN NAV -->
<div id="nav">
    <ul>
        <li><a href="index-admin.php">HORROR</a></li>
        <li><a href="anime-admin.php">ANIME</a></li>
        <li><a href="hollywood-admin.php">HOLLYWOOD</a></li>
        <li><a href="drakor-admin.php">DRAKOR</a></li>
        <li><a href="romance-admin.php">ROMANCE</a></li>
        <li><a href="superhero-admin.php">SUPERHERO</a></li>
        <li><a href="advanture-admin.php">ADVENTURE</a></li>

    </ul>
</div>
<!-- END NAV -->
<!-- BEGIN SUB NAV -->
<div id="sub-nav">
    <ul>
        <li class="title">Stay in the know:</li>
        <li><a href="index-admin.php">Kembali</a></li>
        <li>|</li>
        <li><a href="komentar-admin.php">DATA KOMENTAR</a></li>
        <li>|</li>
        <li><a href="https://www.instagram.com/ryaadz_/">Instagram</a></li>
        <li>|</li>
        <li><img src="img/icons/rss.png" alt="" /><a
                href="https://www.youtube.com/channel/UCOgG58ZxNvKQ56BBQkpUnrA">Subscribe</a></li>
        <li>|</li>
        <li><img src="img/icons/twitter.png" alt="" /><a
                href="https://www.facebook.com/muhammad.r.fadillah.9883">Facebook</a></li>
    </ul>
</div>
<!-- END SUB NAV -->
<!-- BEGIN CONTENT WRAPPER -->
<div id="content-wrapper">
    <!-- BEGIN MAIN -->
    </head>

    <body>
        <h2 align="center" class="mt-5 mb-5"> DATA KOMENTAR</h2>

            <div class="tabelku mt-0 mb-0">
                <div class="text-center">
                <h5 class="mb-4">KOMENTAR <span style="color: #dc0000;">HORROR</span></h5>
                </div>
                <table class="table table-bordered">
                    <thead>
                        <tr class="table-dark">
                            <th class="text-center" scope="col">KOMENTAR</th>
                            <th class="text-center" scope="col">PENGATURAN</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include 'koneksi.php';
                        $no = 1;
                        $data = mysqli_query($koneksi, "select * from komentar");
                        while ($d = mysqli_fetch_array($data)) {
                            ?>
                            <tr class="text-center">
                                <td>
                                    <?php echo $d['komentar']; ?>
                                </td>
                                <td>
                                    <a type="submit" class="link-komentar"
                                        href="hapus-komentar.php?id=<?= $d["id"]; ?>">HAPUS</a>
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                        <style>
                            .link-komentar {
                                text-decoration: none;
                                color: #dc0000;
                                opacity: 60%;
                            }

                            .link-komentar:hover {
                                opacity: 100%;
                            }
                        </style>
                    </tbody>
                </table>
            </div>

            <div class="tabelku mt-5 mb-0">
                <div class="text-center">
                <h5 class="mb-4">KOMENTAR <span style="color: #dc0000;">ANIME</span></h5>
                </div>
                <table class="table table-bordered">
                    <thead>
                        <tr class="table-dark">
                            <th class="text-center" scope="col">KOMENTAR</th>
                            <th class="text-center" scope="col">PENGATURAN</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include 'koneksi.php';
                        $no = 1;
                        $data = mysqli_query($koneksi, "select * from komentar_anime");
                        while ($d = mysqli_fetch_array($data)) {
                            ?>
                            <tr class="text-center">
                                <td>
                                    <?php echo $d['komentar']; ?>
                                </td>
                                <td>
                                    <a type="submit" class="link-komentar"
                                        href="hapus-komentar-anime.php?id=<?= $d["id"]; ?>">HAPUS</a>
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                        <style>
                            .link-komentar {
                                text-decoration: none;
                                color: #dc0000;
                                opacity: 60%;
                            }

                            .link-komentar:hover {
                                opacity: 100%;
                            }
                        </style>
                    </tbody>
                </table>
            </div>

            <div class="tabelku mt-5 mb-0">
                <div class="text-center">
                <h5 class="mb-4">KOMENTAR <span style="color: #dc0000;">HOLLYWOOD</span></h5>
                </div>
                <table class="table table-bordered">
                    <thead>
                        <tr class="table-dark">
                            <th class="text-center" scope="col">KOMENTAR</th>
                            <th class="text-center" scope="col">PENGATURAN</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include 'koneksi.php';
                        $no = 1;
                        $data = mysqli_query($koneksi, "select * from komentar_hollywood");
                        while ($d = mysqli_fetch_array($data)) {
                            ?>
                            <tr class="text-center">
                                <td>
                                    <?php echo $d['komentar']; ?>
                                </td>
                                <td>
                                    <a type="submit" class="link-komentar"
                                        href="hapus-komentar-hollywood.php?id=<?= $d["id"]; ?>">HAPUS</a>
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                        <style>
                            .link-komentar {
                                text-decoration: none;
                                color: #dc0000;
                                opacity: 60%;
                            }

                            .link-komentar:hover {
                                opacity: 100%;
                            }
                        </style>
                    </tbody>
                </table>
            </div>

            <div class="tabelku mt-5 mb-0">
                <div class="text-center">
                <h5 class="mb-4">KOMENTAR <span style="color: #dc0000;">DRAKOR</span></h5>
                </div>
                <table class="table table-bordered">
                    <thead>
                        <tr class="table-dark">
                            <th class="text-center" scope="col">KOMENTAR</th>
                            <th class="text-center" scope="col">PENGATURAN</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include 'koneksi.php';
                        $no = 1;
                        $data = mysqli_query($koneksi, "select * from komentar_drakor");
                        while ($d = mysqli_fetch_array($data)) {
                            ?>
                            <tr class="text-center">
                                <td>
                                    <?php echo $d['komentar']; ?>
                                </td>
                                <td>
                                    <a type="submit" class="link-komentar"
                                        href="hapus-komentar-drakor.php?id=<?= $d["id"]; ?>">HAPUS</a>
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                        <style>
                            .link-komentar {
                                text-decoration: none;
                                color: #dc0000;
                                opacity: 60%;
                            }

                            .link-komentar:hover {
                                opacity: 100%;
                            }
                        </style>
                    </tbody>
                </table>
            </div>

            <div class="tabelku mt-5 mb-0">
                <div class="text-center">
                <h5 class="mb-4">KOMENTAR <span style="color: #dc0000;">ROMANCE</span></h5>
                </div>
                <table class="table table-bordered">
                    <thead>
                        <tr class="table-dark">
                            <th class="text-center" scope="col">KOMENTAR</th>
                            <th class="text-center" scope="col">PENGATURAN</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include 'koneksi.php';
                        $no = 1;
                        $data = mysqli_query($koneksi, "select * from komentar_romance");
                        while ($d = mysqli_fetch_array($data)) {
                            ?>
                            <tr class="text-center">
                                <td>
                                    <?php echo $d['komentar']; ?>
                                </td>
                                <td>
                                    <a type="submit" class="link-komentar"
                                        href="hapus-komentar-romance.php?id=<?= $d["id"]; ?>">HAPUS</a>
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                        <style>
                            .link-komentar {
                                text-decoration: none;
                                color: #dc0000;
                                opacity: 60%;
                            }

                            .link-komentar:hover {
                                opacity: 100%;
                            }
                        </style>
                    </tbody>
                </table>
            </div>

            <div class="tabelku mt-5 mb-0">
                <div class="text-center">
                <h5 class="mb-4">KOMENTAR <span style="color: #dc0000;">SUPERHERO</span></h5>
                </div>
                <table class="table table-bordered">
                    <thead>
                        <tr class="table-dark">
                            <th class="text-center" scope="col">KOMENTAR</th>
                            <th class="text-center" scope="col">PENGATURAN</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include 'koneksi.php';
                        $no = 1;
                        $data = mysqli_query($koneksi, "select * from komentar_superhero");
                        while ($d = mysqli_fetch_array($data)) {
                            ?>
                            <tr class="text-center">
                                <td>
                                    <?php echo $d['komentar']; ?>
                                </td>
                                <td>
                                    <a type="submit" class="link-komentar"
                                        href="hapus-komentar-superhero.php?id=<?= $d["id"]; ?>">HAPUS</a>
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                        <style>
                            .link-komentar {
                                text-decoration: none;
                                color: #dc0000;
                                opacity: 60%;
                            }

                            .link-komentar:hover {
                                opacity: 100%;
                            }
                        </style>
                    </tbody>
                </table>
            </div>

            <div class="tabelku mt-5 mb-0">
                <div class="text-center">
                <h5 class="mb-4">KOMENTAR <span style="color: #dc0000;">ADVANTURE</span></h5>
                </div>
                <table class="table table-bordered">
                    <thead>
                        <tr class="table-dark">
                            <th class="text-center" scope="col">KOMENTAR</th>
                            <th class="text-center" scope="col">PENGATURAN</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include 'koneksi.php';
                        $no = 1;
                        $data = mysqli_query($koneksi, "select * from komentar_advanture");
                        while ($d = mysqli_fetch_array($data)) {
                            ?>
                            <tr class="text-center">
                                <td>
                                    <?php echo $d['komentar']; ?>
                                </td>
                                <td>
                                    <a type="submit" class="link-komentar"
                                        href="hapus-komentar-advanture.php?id=<?= $d["id"]; ?>">HAPUS</a>
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                        <style>
                            .link-komentar {
                                text-decoration: none;
                                color: #dc0000;
                                opacity: 60%;
                            }

                            .link-komentar:hover {
                                opacity: 100%;
                            }
                        </style>
                    </tbody>
                </table>
            </div>



        <!-- BEGIN FOOTER -->
        <div id="footer">
            <ul>
        <li>&copy; 2023 <a href="#">Production Rydzz</a></li>
        <li>|</li>
        <li><a href="#">THANKS FOR COMING!</a></li>
        <li>|</li>
        <li>Designed by <a href="http://www.instagram.com/ryaadz_">Ryaadzz Dragneel</a></li>
            </ul>
        </div>
        <!-- END FOOTER -->

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
            crossorigin="anonymous"></script>
    </body>

    </html>