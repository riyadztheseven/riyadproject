<html>
<head>
	<title>Menampilkan Data</title>
</head>
<body>
 
	<h2>Menampilkan Data komentar</h2>
	<br/>
	<br/>
    <a href="tambah.php">+ TAMBAH kometar</a>
	<br/>
	<table border : collapse;>
		<tr>
			<th>no</th>
            <th>id</th>
			<th>nama</th>
            <th>Komentar</th>
			<th>aksi</th>
		</tr>
		
		<?php 
		include 'koneksi.php';
		$no = 1;
		$data = mysqli_query($koneksi,"select * from komentar");
		while($d = mysqli_fetch_array($data)){
			?>
			<tr>
				<td><?php echo $no++; ?></td>
                <td><?php echo $d['id']; ?></td>
                <td><?php echo $d['nama']; ?></td>
                <td><?php echo $d['komentar']; ?></td>            
				<td>
				<a href="#" onclick="confirmEdit(<?php echo $d['id']; ?>)" class="button-edit" >EDIT</a>
                    <a href="#" onclick="confirmDelete(<?php echo $d['id']; ?>)"  class="button-hapus">HAPUS</a>
                    </td>
            </tr>
            <?php 
        }
        ?>
    </table>

    <script>
        function confirmEdit(id) {
            var confirmEdit = confirm("Apakah Anda yakin ingin mengedit?");
            if (confirmEdit) {
                window.location.href = "edit.php?id=" + id;
            }
        }

        function confirmDelete(id) {
            var confirmDelete = confirm("Apakah Anda yakin ingin menghapus?");
            if (confirmDelete) {
                window.location.href = "hapus.php?id=" + id;
            }
        }
        function showNotification(message) {
            alert(message);
        }

        <?php
        // Mengecek apakah query parameter 'hapus' ada pada URL
        if (isset($_GET['edit']) && $_GET['edit'] == 'sukses') {
            echo "showNotification('Data Anda Telah Diedit');";
        }
        ?>
        function showNotification(message) {
            alert(message);
        }

        <?php
        // Mengecek apakah query parameter 'hapus' ada pada URL
        if (isset($_GET['hapus']) && $_GET['hapus'] == 'sukses') {
            echo "showNotification('Data Anda Telah Dihapus');";
        }
        ?>
    </script>
</body>
</html>