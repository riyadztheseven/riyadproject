<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">

<head>
    <style>
        body {
            background-color: lightblue;
            background-image: url('image/bg3.jpg');
        }
    </style>
    <title>Kotak Pencarian</title>
    <style>
        .search-container {
            text-align: center;
            margin-top: 50px;
        }

        .search-box {
            padding: 10px;
            width: 300px;
            border: 1px solid #ccc;
            border-radius: 0px;
            font-size: 16px;
        }

        .search-button {
            padding: 10px 20px;
            background-color: #007BFF;
            color: #fff;
            border: none;
            border-radius: 0px;
            cursor: pointer;
        }
    </style>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>


</div>
</nav>
<title>Canuckington Post</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" charset="utf-8" />
</head>

<!-- BEGIN TOP -->
<div id="top">
    

</div>
<!-- END TOP -->
<!-- BEGIN HEADER -->
<div id="header">
    <div class="brand">
        <p class="fw-bold fs-1 mt-3 mb-0">ADM<span style="color: #dc0000;">I</span>N P<span style="color: #dc0000;">A</span>GE</p>
        <p class="mb-0">Dalam kategori Horror, Anime, Hollywood, Drakor, Romance, Superhero, dan Adventure</p>
    </div>
</div>

<!-- END HEADER -->
<!-- BEGIN NAV -->
<div id="nav">
    <ul>
        <li><a href="index-admin.php">HORROR</a></li>
        <li><a href="anime-admin.php">ANIME</a></li>
        <li><a href="hollywood-admin.php">HOLLYWOOD</a></li>
        <li><a href="drakor-admin.php">DRAKOR</a></li>
        <li><a href="romance-admin.php">ROMANCE</a></li>
        <li><a href="superhero-admin.php">SUPERHERO</a></li>
        <li><a href="advanture-admin.php">ADVENTURE</a></li>
        <li><a href="tambah-anime.php">TAMBAH KONTEN</a></li>

    </ul>
</div>
<!-- END NAV -->
<!-- BEGIN SUB NAV -->
<div id="sub-nav">
    <ul>
        <li class="title">Stay in the know:</li>
        <li><a href="index.php" onclick="return confirm('Yakin ingin logout?')">Logout Admin</a></li>
        <li>|</li>
        <li><a href="https://www.instagram.com/ryaadz_/">Instagram</a></li>
        <li>|</li>
        <li><img src="img/icons/rss.png" alt="" /><a
                href="https://www.youtube.com/channel/UCOgG58ZxNvKQ56BBQkpUnrA">Subscribe</a></li>
        <li>|</li>
        <li><img src="img/icons/twitter.png" alt="" /><a
                href="https://www.facebook.com/muhammad.r.fadillah.9883">Facebook</a></li>
    </ul>
</div>
<!-- END SUB NAV -->
<!-- BEGIN CONTENT WRAPPER -->
<div id="content-wrapper">
    <!-- BEGIN MAIN -->




    <h2 align="center" class="mt-4 mb-5">PENGATURAN ANIME</h2>
    </head>

    <body>
        <?php
        include 'koneksi.php';
        $query = "SELECT * FROM anime";
        $result = $koneksi->query($query);
        ?>

        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <div class="text">
                <img src="<?php echo $row["gambar"]; ?>" style="width : 400px">
                <div>
                    <p class="mb-4 small opacity-50">
                        Dipublish pada tanggal :
                        <?php echo $row["publish"]; ?>
                    </p>
                    <h2 class="mt-3 mb-2">
                        <?php echo $row["judul"]; ?>
                    </h2>
                    <p class="mb-4">
                        <?php echo $row["deskripsi"]; ?>
                    </p>
                </div>
                <div class="mb-3">
                    <p>Jumlah Episode :
                        <?php echo $row["jumlah_episode"]; ?>
                    </p>
                    <p>Musim Rilis :
                        <?php echo $row["musim_rilis"]; ?>
                    </p>
                    <p>Studio yang Memproduksi :
                        <?php echo $row["studio_produksi"]; ?>
                    </p>
                    <p>Durasi Per Episode :
                        <?php echo $row["durasi_episode"]; ?>
                    </p>
                    <p>Genre :
                        <?php echo $row["genre"]; ?>
                    </p>
                </div>
                <div class="mb-5 text-start">
                    <a type="submit" class="btn btn-danger" style="border-radius: 0px; padding: 4px 15px 4px 15px;"
                        href="edit-anime.php?id=<?= $row["id"]; ?>">Edit Kontent</a>
                    <a type="submit" class="btn btn-danger" style="border-radius: 0px; padding: 4px 15px 4px 15px;"
                        href="hapus-anime.php?id=<?= $row["id"]; ?>" onclick="return confirm('Yakin ingin menghapus konten?')">Hapus konten</a>
                </div>
            </div>
        <?php } ?>


        <!-- BEGIN FOOTER -->
        <div id="footer">
            <ul>
        <li>&copy; 2023 <a href="#">Production Rydzz</a></li>
        <li>|</li>
        <li><a href="#">THANKS FOR COMING!</a></li>
        <li>|</li>
        <li>Designed by <a href="http://www.instagram.com/ryaadz_">Ryaadzz Dragneel</a></li>
            </ul>
        </div>
        <!-- END FOOTER -->

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
            crossorigin="anonymous"></script>
    </body>

    </html>