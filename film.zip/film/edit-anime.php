<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">

<head>
    <style>
        body {
            background-color: lightblue;
            background-image: url('image/bg3.jpg');
        }
    </style>
    <title>Kotak Pencarian</title>
    <style>
        .search-container {
            text-align: center;
            margin-top: 50px;
        }

        .search-box {
            padding: 10px;
            width: 300px;
            border: 1px solid #ccc;
            border-radius: 0px;
            font-size: 16px;
        }

        .search-button {
            padding: 10px 20px;
            background-color: #007BFF;
            color: #fff;
            border: none;
            border-radius: 0px;
            cursor: pointer;
        }
    </style>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

</html>

</div>
</nav>
<title>Canuckington Post</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="screen" charset="utf-8" />
</head>


<!-- BEGIN CONTENT WRAPPER -->
<div id="content-wrapper">

    <!-- BEGIN MAIN -->

    <body>
        <?php
        include 'koneksi.php';

        if (isset($_GET['id'])) {
            $id = $_GET['id'];

            // Ambil data berdasarkan ID
            $sql = "SELECT id, judul, gambar, deskripsi, jumlah_episode, musim_rilis, studio_produksi,
            durasi_episode, genre, publish FROM anime WHERE id = $id";
            $result = $koneksi->query($sql);

            if ($result->num_rows == 1) {
                $row = $result->fetch_assoc();
                $judul = $row['judul'];
                $gambar = $row['gambar'];
                $deskripsi = $row['deskripsi'];
                $jumlah_episode = $row['jumlah_episode'];
                $musim_rilis = $row['musim_rilis'];
                $studio_produksi = $row['studio_produksi'];
                $durasi_episode = $row['durasi_episode'];
                $genre = $row['genre'];
                $publish = $row['publish'];

            } else {
                echo "Data tidak ditemukan.";
                exit();
            }
        } else {
            echo "ID tidak diberikan.";
            exit();
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            $newJudul = $_POST['judul'];
            $newGambar = $_POST['gambar'];
            $newDeskripsi = $_POST['deskripsi'];
            $NewJumlahEpisode = $_POST['jumlah_episode'];
            $NewMusimRilis = $_POST['musim_rilis'];
            $newStudioProduksi = $_POST['studio_produksi'];
            $newDurasiEpisode = $_POST['durasi_episode'];
            $newGenre = $_POST['genre'];
            $newPublish = $_POST['publish'];



            $sql_update = "UPDATE anime SET
            judul = '$newJudul', gambar = '$newGambar', deskripsi = '$newDeskripsi',
            jumlah_episode = '$NewJumlahEpisode', musim_rilis = '$NewMusimRilis',
            studio_produksi = '$newStudioProduksi', durasi_episode = '$newDurasiEpisode',
            genre = '$newGenre', publish = '$newPublish' WHERE id = $id";
            if ($koneksi->query($sql_update) === TRUE) {
                header("Location: anime-admin.php");
            } else {
                echo "Error: Data tidak berhasil diperbarui";
            }
        }
        ?>
        <!-- BEGIN HEADER -->
        <div id="header">
            <div style="margin-top: 75px;" class="brand text-center">
                <p class="fw-bold fs-1 mt-3 mb-0">EDIT KONTEN :
                    <span style="color: #dc0000;"><?php echo $judul; ?></span>
                </p>
            </div>
        </div>
        <div class="row">
            <div style="border: 1px solid;" class="text-center mb-5">
                <img width="200px" class="img-fluid mt-5 mb-5" src="<?php echo $gambar; ?>" alt="">
            </div>
            <form method="post">
            <div class="mb-4">
                    <label for="publish" class="form-label fw-semibold">TANGGAL PUBLISH :</label>
                    <input style="border-radius: 0px;" type="text" class="form-control" id="publish" name="publish"
                        value="<?php echo $publish; ?>" required>
                </div>
                <div class="mb-4">
                    <label for="judul" class="form-label fw-semibold">JUDUL :</label>
                    <input style="border-radius: 0px;" type="text" class="form-control" id="judul" name="judul"
                        value="<?php echo $judul; ?>" required>
                </div>
                <div class="mb-4">
                    <label for="gambar" class="form-label fw-semibold">GAMBAR :</label>
                    <input style="border-radius: 0px;" type="text" class="form-control" id="gambar" name="gambar"
                        value="<?php echo $gambar; ?>" required>
                </div>
                <div class="mb-4">
                    <label for="deskripsi" class="form-label fw-semibold">DESKRIPSI :</label>
                    <textarea style="border-radius: 0px; height: 250px;" type="text" class="form-control" id="deskripsi"
                        name="deskripsi" required><?php echo $deskripsi; ?>"</textarea>
                </div>
                <div class="mb-4">
                    <label for="jumlah_episode" class="form-label fw-semibold">JUMLAH EPISODE :</label>
                    <input style="border-radius: 0px;" type="number" class="form-control" id="jumlah_episode"
                        name="jumlah_episode" value="<?php echo $jumlah_episode; ?>" required>
                </div>
                <div class="mb-4">
                    <label for="musim_rilis" class="form-label fw-semibold">TANGGAL RILIS :</label>
                    <input style="border-radius: 0px;" type="text" class="form-control" id="musim_rilis"
                        name="musim_rilis" value="<?php echo $musim_rilis; ?>" required>
                </div>
                <div class="mb-4">
                    <label for="studio_produksi" class="form-label fw-semibold">STUDIO PRODUKSI :</label>
                    <input style="border-radius: 0px;" type="text" class="form-control" id="studio_produksi"
                        name="studio_produksi" value="<?php echo $studio_produksi; ?>" required>
                </div>
                <div class="mb-4">
                    <label for="durasi_episode" class="form-label fw-semibold">DURASI FILM :</label>
                    <input style="border-radius: 0px;" type="time" class="form-control" id="durasi_episode"
                        name="durasi_episode" value="<?php echo $durasi_episode; ?>" required>
                </div>
                <div class="mb-4">
                    <label for="genre" class="form-label fw-semibold">GENRE :</label>
                    <input style="border-radius: 0px;" type="text" class="form-control" id="genre"
                        name="genre" value="<?php echo $genre; ?>" required>
                </div>
                <div class="text-center mt-4 mb-5">
                    <button type="submit" class="btn btn-danger me-5"
                        style="border-radius: 0px; padding: 4px 35px 4px 35px;">Edit Data</button>
                    <a type="submit" class="btn btn-danger ms-5" href="anime-admin.php"
                        style="border-radius: 0px; padding: 4px 35px 4px 35px;">Batal Edit</a>
                </div>
            </form>
        </div>


        <!-- BEGIN FOOTER -->
        <div id="footer">
            <ul>
            <li>&copy; 2023 <a href="#">Production Rydzz</a></li>
        <li>|</li>
        <li><a href="#">THANKS FOR COMING!</a></li>
        <li>|</li>
        <li>Designed by <a href="http://www.instagram.com/ryaadz_">Ryaadzz Dragneel</a></li>
            </ul>
        </div>
        <!-- END FOOTER -->

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
            crossorigin="anonymous"></script>
    </body>

    </html>