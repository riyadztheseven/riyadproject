<?php

$server = "localhost";
$user = "root";
$pass = "";
$database = "film";

$conn = mysqli_connect($server, $user, $pass, $database);

if($conn){
    //die("<script>alert('Gagal tersambung dengan database.')</script>");

}
mysqli_select_db($conn, $database);
?>