<?php
	include 'koneksi.php';
	
	if (isset($_POST['komentar'])) {
		$id = $_POST['id'];
		$nama = $_POST['nama'];
		$Komentar = $_POST['Komentar'];

		$sql = "INSERT INTO komentar (id, nama, Komentar) VALUES ('$id', '$nama', '$Komentar')";
		$result = mysqli_query($koneksi, $sql);

		if (!$result) {
			die("Query gagal dijalankan: " . mysqli_errno($koneksi) . " - " . mysqli_error($koneksi));
		} else {
			header("Location: tampil.php");
			exit();
		}
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data komentar</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="css/style3.css">
</head>
<body>
    <div class="page-content p-5" id="content">
        <button id="sidebarCollapse" type="button" class="btn btn-light bg-white rounded-pill shadow-sm px-4 mb-4"><i class="fa fa-bars mr-2"></i><small class="text-uppercase font-weight-bold">Menu</small></button>

        <div class="content-container">
            <h2>Form Data komentar</h2>
            <form action="" method="POST">
                <div class="form-group">
                    <input type="number" class="form-control" name="id" placeholder="Masukkan id">
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="nama" placeholder="Masukkan nama">
                </div>
                <!-- Perbaikan nama input di bawah ini -->
                <div class="form-group">
                    <input type="text" class="form-control" name="Komentar" placeholder="Masukkan komentar">
                </div>
                <!-- Perbaikan nama input di atas ini -->
                <button name="komentar" type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>

    <script src="js/js.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
