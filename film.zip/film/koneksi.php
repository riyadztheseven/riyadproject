<?php

$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "datafilm";

$koneksi = new mysqli($hostname, $username, $password, $dbname);

?>